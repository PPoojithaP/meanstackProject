const express = require('express');
const router = express.Router();

const Contact = require('../models/contacts');


///api/contacts -- will direct to following method

// retrieving contacts
router.get('/contacts',function(req,res,next){
	//res.send('Retrieving the contacts!');
	Contact.find(function(err,contacts){
		res.json(contacts);
	});
})

//add contact
router.post('/contact',(req,res,next)=>{
	// logic to add contact to db
	//create a new contact 
	let newContact = new Contact({
		first_name: req.body.first_name,
		last_name: req.body.last_name,
		phone: req.body.phone
	});
	newContact.save((err,contact)=>{
		if(err){
			res.json({msg: 'Failed to add contact'});
		}else{
			res.json({msg: 'Contact added successfully! :)'});
		}
	});
});

//delete contacts
 router.delete('/contact/:id',(req,res,next)=>{
	// delete contact from db
	Contact.remove({_id:req.params.id},function(err,result){
		if(err){
			res.json(err);
		}else{
			res.json(result);
		}
	});

});

//not only mentioning the route, we need to export the router as well
module.exports = router;